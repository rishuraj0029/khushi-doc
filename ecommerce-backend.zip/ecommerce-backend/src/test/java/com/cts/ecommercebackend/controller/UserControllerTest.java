package com.cts.ecommercebackend.controller;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.cts.ecommercebackend.controller.UserController;
import com.cts.ecommercebackend.dao.AddressDao;
import com.cts.ecommercebackend.dao.UserDao;
import com.cts.ecommercebackend.dto.AddUserRequest;
import com.cts.ecommercebackend.dto.UserLoginRequest;
import com.cts.ecommercebackend.model.Address;
import com.cts.ecommercebackend.model.User;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {
	
	@Mock
	private UserDao userDao;
	
	@Mock
	private AddressDao addressDao;
	
	@InjectMocks
	private UserController userController;
	
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetAllUsers() {
		List<User> users = new ArrayList<>();
		users.add(createSampleUser());
		
		when(userDao.findAll()).thenReturn(users);
		
		ResponseEntity<?> response = userController.getAllUsers();
		
		// Assert statements for response
	}
	
	@Test
	public void testRegisterUser() {
		AddUserRequest addUserRequest = createSampleAddUserRequest();
		
		Address address = createSampleAddress();
		
		when(addressDao.save(any(Address.class))).thenReturn(address);
		when(userDao.save(any(User.class))).thenReturn(createSampleUser());
		
		ResponseEntity<?> response = userController.registerUser(addUserRequest);
		
		// Assert statements for response
	}
	
	@Test
	public void testLoginUser() {
		UserLoginRequest loginRequest = createSampleUserLoginRequest();
		
		when(userDao.findByEmailIdAndPasswordAndRole(anyString(), anyString(), anyString())).thenReturn(createSampleUser());
		
		ResponseEntity<?> response = userController.loginUser(loginRequest);
		
		// Assert statements for response
	}
	
	@Test
	public void testGetAllDeliveryPersons() {
		List<User> deliveryPersons = new ArrayList<>();
		deliveryPersons.add(createSampleUser());
		
		when(userDao.findByRole(anyString())).thenReturn(deliveryPersons);
		
		ResponseEntity<?> response = userController.getAllDeliveryPersons();
		
		// Assert statements for response
	}
	
	 // Negative test case for logging in with invalid credentials
    @Test
    public void testLoginUserWithInvalidCredentials() {
        UserLoginRequest loginRequest = createSampleUserLoginRequest();

        // Set invalid password to trigger the failure
        loginRequest.setPassword("invalid_password");

        when(userDao.findByEmailIdAndPasswordAndRole(anyString(), anyString(), anyString())).thenReturn(null);

        ResponseEntity<?> response = userController.loginUser(loginRequest);

        // Assert statements for response
    }
 // Negative test case for registering a user with invalid user data
    @Test
    public void testRegisterUserWithInvalidUserData() {
        AddUserRequest addUserRequest = createSampleAddUserRequest();

        // Set an invalid email ID to trigger the failure
        addUserRequest.setEmailId("invalid_email");

        ResponseEntity<?> response = userController.registerUser(addUserRequest);

        // Assert statements for response
    }
	// Helper methods to create sample objects for testing
	
	private User createSampleUser() {
		User user = new User();
		user.setId(1);
		user.setFirstName("Anu");
		user.setLastName("shikha");
		user.setEmailId("anu@ecom.com");
		user.setPassword("password");
		user.setPhoneNo("1234567890");
		user.setAddress(createSampleAddress());
		user.setRole("customer");
		return user;
	}
	
	private Address createSampleAddress() {
		Address address = new Address();
		address.setId(1);
		address.setCity("Bangalore");
		address.setPincode(12345);
		address.setStreet("ABC Street");
		return address;
	}
	
	private AddUserRequest createSampleAddUserRequest() {
		AddUserRequest addUserRequest = new AddUserRequest();
		addUserRequest.setFirstName("Anu");
		addUserRequest.setLastName("shikha");
		addUserRequest.setEmailId("anu@ecom.com");
		addUserRequest.setPassword("password");
		addUserRequest.setPhoneNo("1234567890");
		addUserRequest.setCity("Bangalore");
		addUserRequest.setPincode(12345);
		addUserRequest.setStreet("ABC Street");
		addUserRequest.setRole("customer");
		return addUserRequest;
	}
	
	private UserLoginRequest createSampleUserLoginRequest() {
		UserLoginRequest loginRequest = new UserLoginRequest();
		loginRequest.setEmailId("anu@ecom.com");
		loginRequest.setPassword("password");
		loginRequest.setRole("customer");
		return loginRequest;
	}
}