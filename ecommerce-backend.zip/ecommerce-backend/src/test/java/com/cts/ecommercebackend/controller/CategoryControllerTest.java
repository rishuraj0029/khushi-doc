package com.cts.ecommercebackend.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cts.ecommercebackend.dao.CategoryDao;
import com.cts.ecommercebackend.model.Category;

class CategoryControllerTest {

    private CategoryController categoryController;
    private CategoryDao categoryDao;

    @BeforeEach
    void setUp() {
        categoryDao = mock(CategoryDao.class);
        categoryController = new CategoryController();
        categoryController.setCategoryDao(categoryDao);
    }

    @Test
    void testGetAllCategories() {
        List<Category> categories = new ArrayList<>();
        categories.add(createCategory(1, "Electronics", "Electronic devices and gadgets"));
        categories.add(createCategory(2, "Clothing", "Fashionable clothing for all occasions"));

        when(categoryDao.findAll()).thenReturn(categories);

        ResponseEntity<List<Category>> response = categoryController.getAllCategories();

        verify(categoryDao).findAll();

        assertIterableEquals(categories, response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void testAddCategory() {
        Category category = createCategory(1, "Electronics", "Electronic devices and gadgets");

        when(categoryDao.save(category)).thenReturn(category);

        ResponseEntity<?> response = categoryController.add(category);

        verify(categoryDao).save(category);

        assertEquals(category, response.getBody());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void testGetAllCategoriesWhenNoneAvailable() {
        when(categoryDao.findAll()).thenReturn(new ArrayList<>());

        ResponseEntity<List<Category>> response = categoryController.getAllCategories();

        verify(categoryDao).findAll();

        assertTrue(response.getBody().isEmpty());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

   

    
    // Helper method to create a Category object
    private Category createCategory(int id, String title, String description) {
        Category category = new Category();
        category.setId(id);
        category.setTitle(title);
        category.setDescription(description);
        return category;
    }
}
