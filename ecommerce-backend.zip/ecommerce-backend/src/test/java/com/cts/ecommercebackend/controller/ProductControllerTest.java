package com.cts.ecommercebackend.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.cts.ecommercebackend.dao.CategoryDao;
import com.cts.ecommercebackend.dao.ProductDao;
import com.cts.ecommercebackend.dto.ProductAddRequest;
import com.cts.ecommercebackend.model.Category;
import com.cts.ecommercebackend.model.Product;
import com.cts.ecommercebackend.service.ProductService;
import com.cts.ecommercebackend.utility.StorageService;

public class ProductControllerTest {

	@Mock
	private ProductService productService;

	@Mock
	private ProductDao productDao;

	@Mock
	private CategoryDao categoryDao;

	@Mock
	private StorageService storageService;

	@InjectMocks
	private ProductController productController;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}


	@Test
	public void testGetAllProducts() {
		// Mock Product list
		List<Product> products = new ArrayList<>();
		Product product1 = new Product();
		product1.setId(1);
		product1.setTitle("Product 1");
		Product product2 = new Product();
		product2.setId(2);
		product2.setTitle("Product 2");
		products.add(product1);
		products.add(product2);

		when(productDao.findAll()).thenReturn(products);

		ResponseEntity<?> responseEntity = productController.getAllProducts();

		assertEquals(ResponseEntity.ok(products), responseEntity);
		verify(productDao, times(1)).findAll();
	}

	@Test
	public void testGetProductById() {
		int productId = 1;

		Product product = new Product();
		product.setId(productId);
		product.setTitle("Test Product");

		when(productDao.findById(productId)).thenReturn(Optional.of(product));

		ResponseEntity<?> responseEntity = productController.getProductById(productId);

		assertEquals(ResponseEntity.ok(product), responseEntity);
		verify(productDao, times(1)).findById(productId);
	}

	@Test
	public void testGetProductsByCategories() {
		int categoryId = 1;

		// Mock Product list
		List<Product> products = new ArrayList<>();
		Product product1 = new Product();
		product1.setId(1);
		product1.setTitle("Product 1");
		Product product2 = new Product();
		product2.setId(2);
		product2.setTitle("Product 2");
		products.add(product1);
		products.add(product2);

		when(productDao.findByCategoryId(categoryId)).thenReturn(products);

		ResponseEntity<?> responseEntity = productController.getProductsByCategories(categoryId);

		assertEquals(ResponseEntity.ok(products), responseEntity);
		verify(productDao, times(1)).findByCategoryId(categoryId);
	}

	@Test
	public void testGetProductsByInvalidCategoryId() {
	    int invalidCategoryId = -1;

	    when(productDao.findByCategoryId(invalidCategoryId)).thenReturn(new ArrayList<>());

	    ResponseEntity<?> responseEntity = productController.getProductsByCategories(invalidCategoryId);

	    assertEquals(ResponseEntity.ok(new ArrayList<>()), responseEntity);
	    verify(productDao, times(1)).findByCategoryId(invalidCategoryId);
	}

}