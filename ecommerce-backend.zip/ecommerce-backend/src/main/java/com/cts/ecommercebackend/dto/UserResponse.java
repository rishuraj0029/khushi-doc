package com.cts.ecommercebackend.dto;

public class UserResponse {

}
