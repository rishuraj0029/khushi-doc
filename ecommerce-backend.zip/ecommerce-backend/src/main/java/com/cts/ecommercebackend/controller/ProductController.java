package com.cts.ecommercebackend.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cts.ecommercebackend.dao.*;
import com.cts.ecommercebackend.dto.ProductAddRequest;
import com.cts.ecommercebackend.model.*;
import com.cts.ecommercebackend.service.ProductService;
import com.cts.ecommercebackend.utility.StorageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("api/product")
//@CrossOrigin(origins = "http://localhost:3000")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ProductController {
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductService productService;
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private CategoryDao categoryDao;
	
	@Autowired
	private StorageService storageService;
	
	@Autowired
	private UserDao userDao;
	
	@PostMapping("add")
	public ResponseEntity<?> addProduct(ProductAddRequest productDto) {
		log .info("recieved request for ADD PRODUCT");
		System.out.println(productDto);
		Product product=ProductAddRequest.toEntity(productDto);
		
		 // Negative number validation for price and quantity
	    if (productDto.getPrice() < 0) {
	        log.error("Price cannot be negative!");
	        return ResponseEntity.badRequest().body("Price cannot be negative!");
	    }
	    if (productDto.getQuantity() < 0) {
	        log.error("Quantity cannot be negative!");
	        return ResponseEntity.badRequest().body("Quantity cannot be negative!");
	    }
		
		Optional<Category> optional = categoryDao.findById(productDto.getCategoryId());
		Category category = null;
		if(optional.isPresent()) {
			category = optional.get();
		}
		
		product.setCategory(category);
		productService.addProduct(product, productDto.getImage());
		
		log .info("Product Added!!!");
		return ResponseEntity.ok(product);
		
	}
	
	@GetMapping("all")
	public ResponseEntity<?> getAllProducts() {
		
		log .info("request came for getting all products");
		
		List<Product> products = new ArrayList<Product>();
		
		products = productDao.findAll();
		
		log .info("response sent for all products!!!");
		
		return ResponseEntity.ok(products);
		
	}
	
	@GetMapping("id")
	public ResponseEntity<?> getProductById(@RequestParam("productId") int productId) {
		
		log .info("request came for getting Product by Product Id");
		
		Product product = new Product();
		
		Optional<Product> optional = productDao.findById(productId);
		
		if(optional.isPresent()) {
			product = optional.get();
		}
		log .info("response sent for products by ID!!!");
		
		return ResponseEntity.ok(product);
		
	}
	
	@GetMapping("category")
	public ResponseEntity<?> getProductsByCategories(@RequestParam("categoryId") int categoryId) {
		
		log .info("request came for getting all products by category");
		
		List<Product> products = new ArrayList<Product>();
		
		products = productDao.findByCategoryId(categoryId);
		
		log .info("response sent for products by CATEGORY!!!");
		
		return ResponseEntity.ok(products);
		
	}
	

	

	


}
