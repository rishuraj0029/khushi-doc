package com.cts.ecommercebackend.service;


import org.springframework.web.multipart.MultipartFile;

import com.cts.ecommercebackend.model.Product;

public interface ProductService {
	
	void addProduct(Product product, MultipartFile productImmage);

}
