package com.cts.ecommercebackend.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cts.ecommercebackend.dao.CategoryDao;
import com.cts.ecommercebackend.model.Category;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping("api/category")
//@CrossOrigin(origins = "http://localhost:3000")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CategoryController {

	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(CategoryController.class);

	
	private CategoryDao categoryDao;
	
	@Autowired
    public void setCategoryDao(CategoryDao categoryDao) {
        this.categoryDao = categoryDao;
    }

	@GetMapping("all")
	public ResponseEntity<List<Category>> getAllCategories() {
		
		log.info("request came for getting all categories");
		
		List<Category> categories = this.categoryDao.findAll();
		
		ResponseEntity<List<Category>> response = new ResponseEntity<>(categories, HttpStatus.OK);
		
		log.info("response sent for all categories");
		
		return response;
		
	}
	
	@PostMapping("add")
	public ResponseEntity add(@RequestBody Category category) {
		
		log.info("request came for add category");
		
		
		Category c = categoryDao.save(category);
		
		if(c != null) {
			log.info("Categories Added");
			return new ResponseEntity( c ,HttpStatus.OK);
		}
		
		else {
			log.info("response not sent");
			return new ResponseEntity("Failed to add category!",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
}

