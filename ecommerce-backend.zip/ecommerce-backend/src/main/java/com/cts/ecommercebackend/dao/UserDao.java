package com.cts.ecommercebackend.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cts.ecommercebackend.model.User;

@Repository
public interface UserDao extends JpaRepository<User, Integer> {
	
	User findByEmailIdAndPasswordAndRole(String emailId, String password, String role);
	List<User> findByRole(String role);
    @Query("SELECT u FROM User u WHERE u.emailId = :emailId AND u.role = :role")
    User findByEmailIdAndRole(@Param("emailId") String emailId, @Param("role") String role);

	
}
